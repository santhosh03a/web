package com.jspdemo.Controller;

import com.jspdemo.Student;
import com.jspdemo.Model.Model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Controllers {
    @Autowired
    Model model;

    @RequestMapping("/home")
    public String home() {
        return "home";
    }

    @RequestMapping("/form")
    public String form() {
        return "form";
    }

    @RequestMapping("/save")
    public String save(@ModelAttribute("student") Student student) {
        model.add(student);
        model.getStudents();
        return "completed";
    }
}
