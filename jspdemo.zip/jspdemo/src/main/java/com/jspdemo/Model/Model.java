package com.jspdemo.Model;

import java.util.ArrayList;
import java.util.List;

import com.jspdemo.Student;
import org.springframework.stereotype.Repository;

@Repository
public class Model {
    List<Student> list = new ArrayList<>();

    public Student add(Student student) {
        this.list.add(student);
        return student;
    }

    public List<Student> getStudents() {
        return list;
    }
}
