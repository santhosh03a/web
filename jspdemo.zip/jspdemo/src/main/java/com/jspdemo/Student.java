package com.jspdemo;

public class Student {
    String name;
    String college;
    String branch;
    int age;

    public Student(String name, String college, String branch, int age) {
        this.name = name;
        this.college = college;
        this.branch = branch;
        this.age = age;
    }

}
