import java.sql.*;
import java.util.Scanner;

import com.mysql.cj.protocol.Resultset;
public class studentdetails {
    Scanner sc=new Scanner(System.in);
    String addr = "jdbc:mysql://localhost:3306/college";
    String username = "root";
    String password = "root";
    Connection conn = null;
    Statement stm;
    void insert(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(addr, username, password);
            stm = conn.createStatement();
            System.out.println("enter student usn");
            String usn=sc.next();
            System.out.println("enter student name");
            String name=sc.next();
            System.out.println("enter student age");
            int  age=sc.nextInt();
            System.out.println("enter student branch");
            String branch=sc.next();
            System.out.println("enter student place");
            String place=sc.next();
            String sql = "insert into student values(?,?,?,?,?)";
            PreparedStatement psm=conn.prepareStatement(sql);
            psm.setString(1,usn);
            psm.setString(2,name);
            psm.setInt(3,age);
            psm.setString(4,branch);
            psm.setString(5,place);
            psm.execute();
            conn.close();
        } catch (ClassNotFoundException e) {

        } catch (SQLException e) {

        }

    }
    void delete() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(addr, username, password);
            stm = conn.createStatement();
            System.out.println("enter student usn to delete");
            String usn = sc.next();
            String sql = "delete from student where usn=?";
            PreparedStatement psm = conn.prepareStatement(sql);
            psm.setString(1, usn);
            psm.executeUpdate();

            conn.close();
        } catch (ClassNotFoundException e) {

        } catch (SQLException e) {

        }
    }
    void display() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(addr, username, password);
            stm = conn.createStatement();
            String sql = "select * from student";
            ResultSet rs = stm.executeQuery(sql);
            while (rs.next()) {
                System.out.println("usn=" + rs.getString(1) + " name=" + rs.getString(2) + " age=" + rs.getInt(3)+ " branch=" + rs.getString(4) + " place=" + rs.getString(5) );
            }
            conn.close();
        } catch (ClassNotFoundException e) {

        } catch (SQLException e) {

        }
    }
}
