import java.util.Scanner;

public class jdbcconnection {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        studentdetails sd=new studentdetails();

        while(true){
            System.out.println("1.Insert 2.delete 3.display 4.Exit");
            int ch=sc.nextInt();
            switch(ch){
                case 1:
                    System.out.println("enter the student details");
                    sd.insert();
                    break;
                case 2:
                    sd.delete();
                    break;
                case 3:sd.display();
                    break;
                case 4:System.exit(0);
                default:
                    System.out.println("enter a valid choice");
            }
        }
    }
}
