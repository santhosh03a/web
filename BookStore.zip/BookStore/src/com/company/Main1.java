package com.company;

public interface Main1 {
    public abstract void bookOperation();
    public abstract void userOperation();
    public abstract void cartOperation();

}
