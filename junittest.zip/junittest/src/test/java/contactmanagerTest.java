

import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

class contactmanagerTest {
    private static contactmanager contactmanager;
    @BeforeAll
    public static void setupAll(){
        System.out.println("should execute before all test case");
    }
    @BeforeEach
    public void setup(){
        System.out.println("instatiating contact manager");
        contactmanager=new contactmanager();
    }
    @Test
    @DisplayName("should add a contact")
    public void shouldcreatecontact(){
           contactmanager.addcontact("santhosh","Kumar","0123456789");
           Assertions.assertFalse(contactmanager.getAllcontacts().isEmpty());
           Assertions.assertEquals(1,contactmanager.getAllcontacts().size());
    }
    @Test
    @DisplayName("should not create contact when first name is null")
    public void throwErrorWhenFirstNameIsNull(){
        Assertions.assertThrows(RuntimeException.class,()->{
            contactmanager.addcontact(null,"b","0987654324");
        });
    }
    @Test
    @DisplayName("should not create contact when phone number is null")
    public void throwErrorWhenPhoneNumberIsNull(){
        Assertions.assertThrows(RuntimeException.class,()->{
            contactmanager.addcontact("Santhosh","b",null);
        });
    }
    @Test
    void addcontact() {
    }

    @Test
    void getAllcontacts() {
    }
    @AfterEach
    public void finish(){
        System.out.println("executed after each test case");
    }
    @AfterAll
    public static void finishAll(){
        System.out.println("executed at last");
    }
}